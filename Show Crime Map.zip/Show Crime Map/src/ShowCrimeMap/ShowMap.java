/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ShowCrimeMap;

import java.awt.*;  
import java.awt.event.*;  
import java.awt.geom.*;  
import java.awt.image.BufferedImage;  
import java.io.*;  
import java.net.*;  
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;  

import javax.swing.*;  
import javax.swing.event.*;  
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
   
   

public class ShowMap extends JFrame implements MouseInputListener
{
    private JButton addPoint = new JButton("Add New Point");
    ShowMap()
    {
        ImagePanel panel = new ImagePanel();  
        ImageZoom zoom = new ImageZoom(panel);  
        //JFrame f = new JFrame();  
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
        getContentPane().add(zoom.getUIPanel(), "North");  
        getContentPane().add(new JScrollPane(panel));  
        setSize(1000,700);  
        setLocationRelativeTo(null);
        setExtendedState(this.getExtendedState() | JFrame.MAXIMIZED_BOTH);
        setVisible(true);
        
        panel.add(addPoint);
        panel.addMouseListener(this);
        
        addPoint.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) 
            {
                try{
                String s = JOptionPane.showInputDialog("Enter New Point: ");
                String ss[]=s.split(",");
                int x = Integer.parseInt(ss[0]);
                int y = Integer.parseInt(ss[1]);
                Graphics g;
                g = getGraphics();
                Add_New_Point(g, x, y);
                //JOptionPane.showMessageDialog(null, s);
                }catch(Exception ex){
                    System.out.println(ex.getMessage());
                }
                    
                
                
            }
        });
        
    }
    public void Add_New_Point(Graphics g, int x, int y)
    {
        g.setColor(Color.red);
        g.fillRect(x, y, 10, 10);
        //repaint();
    }
    public static void main(String[] args) 
    {  
        new ShowMap();
        
        
        
    }  

    @Override
    public void mouseClicked(MouseEvent e) {
        System.out.println("MouseClicked: "+e.getX()+","+e.getY());
        JOptionPane.showMessageDialog(null, "Mouse Clicked: "+e.getX()+","+e.getY());
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mousePressed(MouseEvent e) {
        System.out.println("MousePressed: "+e.getX()+","+e.getY());
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        System.out.println("MouseReleased: "+e.getX()+","+e.getY());
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        System.out.println("MouseEntered: "+e.getX()+","+e.getY());
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mouseExited(MouseEvent e) {
        System.out.println("MouseExited: "+e.getX()+","+e.getY());
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mouseDragged(MouseEvent e) {
        System.out.println("MouseDragged: "+e.getX()+","+e.getY());
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mouseMoved(MouseEvent e) {
        System.out.println("MouseMoved: "+e.getX()+","+e.getY());
        
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}  
class ImagePanel extends JPanel  
{  
    BufferedImage image;  
    double scale;  
   
    public ImagePanel()  
    {  
        loadImage();  
        scale = 1.0;  
        setBackground(Color.black);  
    }  
   
    protected void paintComponent(Graphics g)  
    {  
        super.paintComponent(g);  
        Graphics2D g2 = (Graphics2D)g;  
        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION,  
                            RenderingHints.VALUE_INTERPOLATION_BICUBIC);  
        int w = getWidth();  
        int h = getHeight();  
        int imageWidth = image.getWidth();  
        int imageHeight = image.getHeight();  
        double x = (w - scale * imageWidth)/2;  
        double y = (h - scale * imageHeight)/2;  
        AffineTransform at = AffineTransform.getTranslateInstance(x,y);  
        at.scale(scale, scale);  
        g2.drawRenderedImage(image, at);  
    }
    
    
    @Override
    public void paint(Graphics g) 
    {
        super.paint(g); //To change body of generated methods, choose Tools | Templates.
        g.setColor(Color.red);
        //g.fillRect(314, 247, 10, 10);
    }
    
   
    /** 
     * For the scroll pane. 
     */  
    public Dimension getPreferredSize()  
    {  
        int w = (int)(scale * image.getWidth());  
        int h = (int)(scale * image.getHeight());  
        return new Dimension(w, h);  
    }  
   
    public void setScale(double s)  
    {  
        scale = s;  
        revalidate();      // update the scroll pane  
        repaint();  
    }  
   
    private void loadImage()  
    {  
        String fileName = "BangladeshMap.jpg";  
        try  
        {  
            URL url = getClass().getResource(fileName);  
            //image = ImageIO.read(url);
            image = ImageIO.read(new FileInputStream("BangladeshMap.jpg"));
            //this.icon = ImageIO.read(new FileInputStream("res/test.txt"));
        }  
        catch(MalformedURLException mue)  
        {  
            System.out.println("URL trouble: " + mue.getMessage());  
        }  
        catch(IOException ioe)  
        {  
            System.out.println("read trouble: " + ioe.getMessage());  
        }  
    }  
}  
   
class ImageZoom  
{  
    ImagePanel imagePanel;  
   
    public ImageZoom(ImagePanel ip)  
    {  
        imagePanel = ip;  
    }  
   
    public JPanel getUIPanel()  
    {  
        SpinnerNumberModel model = new SpinnerNumberModel(1.0, 0.1, 1.4, .01);  
        final JSpinner spinner = new JSpinner(model);  
        spinner.setPreferredSize(new Dimension(45, spinner.getPreferredSize().height));  
        spinner.setEnabled(false);
        spinner.addChangeListener(new ChangeListener()  
        {  
            public void stateChanged(ChangeEvent e)  
            {  
                float scale = ((Double)spinner.getValue()).floatValue();  
                imagePanel.setScale(scale);  
            }  
        });
        
        JPanel panel = new JPanel();  
        panel.add(new JLabel("scale"));  
        panel.add(spinner);  
        return panel;  
    }  
}  