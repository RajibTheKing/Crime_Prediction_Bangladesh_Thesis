/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ShowCrimeMap;

import java.io.BufferedReader;
import java.io.FileReader;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

/**
 *
 * @author Rajib
 */
public class TrackLocation 
{
    
    public void Get_All_Location()
    {
        try {
            
            BufferedReader br = new BufferedReader(new FileReader("BangladeshLocation.xml"));
            String str="";
            String source = "";
            while( (str=br.readLine()) !=null)
            {
                source+=str;
                source = source + "\r\n";
               
            }
            //System.out.println(source);
            Document doc = Jsoup.parse(source);
            Elements el = doc.getElementsByTag("district_name");
            
            for(Element f:el)
            {
                System.out.println(f.toString());
                
            }
            
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }
    
}
