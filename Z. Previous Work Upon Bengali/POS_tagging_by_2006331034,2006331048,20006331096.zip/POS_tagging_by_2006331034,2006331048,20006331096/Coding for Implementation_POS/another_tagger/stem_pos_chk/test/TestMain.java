/*
public class TestMain {

    public static void main(String[] args) {
        TestCharReplace t = new TestCharReplace();
        //t.kar_replace(null, null);
        //t.kar_replace("C:/Users/rakib/Desktop/Thesis-15.01.11/Test/k_p_b/bbbb_final.txt", "C:/Users/rakib/Desktop/Thesis-15.01.11/Test/k_p_b/freq_count.txt");

//        AddRules a = new AddRules();
//        String str = a.checkRules( "ইয়ে" ,"ADJ");
//                System.out.println(str);
    }
}
 * */
