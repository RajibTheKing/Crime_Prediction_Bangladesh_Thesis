package test_potter;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.StringTokenizer;
import java.util.Vector;

public class CheckSuffix {

    public CheckSuffix() {
    }
    HashMap dictionary_tree = new HashMap();
    Vector protoy = new Vector();
    Vector uposorgo = new Vector();
    Vector kal = new Vector();
    Vector bivokti = new Vector();
    String stemmed = "";
    String result_token = "";
    String result_pos = "";
    String result = "";

    public void Dictionary_hash() {
        String str;

        try {

            //FileInputStream fis1 = new FileInputStream("C:/Users/rakib/Desktop/Thesis-15.01.11/Test/dictionary/Word_Pos_pals.txt");
             FileInputStream fis1 = new FileInputStream("E://ThesisResource_pos/another_tagger/dictionary/Word_Pos_pals.txt");
            InputStreamReader isr1 = new InputStreamReader(fis1, "utf-8");
            BufferedReader br1 = new BufferedReader(isr1);

            while ((str = br1.readLine()) != null) {    // Used Hashmap,Tokennized hash content-> Inserted

                StringTokenizer token = new StringTokenizer(str);
                int flag = 0;
                String pos = "", t_string = "";
                while (token.hasMoreTokens()) {
                    if (flag == 0) {
                        t_string = token.nextToken();
                        flag = 1;
                    } else {
                        pos = token.nextToken();
                    }
                }

                dictionary_tree.put(t_string, pos);     // Add content to the treeset

//                if(dictionary_tree.containsKey(t_string))
//                String s = dictionary_tree.get(t_string).toString();

            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void vector_kal() {


        String str_kal, vector_str;

        try {
            //FileInputStream fis_kal = new FileInputStream("C:/Users/rakib/Desktop/Thesis-15.01.11/Test/dictionary/kal.txt");
              FileInputStream fis_kal = new FileInputStream("E://ThesisResource_pos/another_tagger/dictionary/kal.txt");
            InputStreamReader isr_kal = new InputStreamReader(fis_kal, "UTF-8");
            BufferedReader b_kal = new BufferedReader(isr_kal);
            int strtKey = b_kal.read();

            while ((str_kal = b_kal.readLine()) != null) {
                //System.out.println("Got it " + str_uposorgo.toString());

                kal.add(str_kal);

            }

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public void vector_bivokti() {

        String str_bivokti;

        try {
            //FileInputStream fis_bivokti = new FileInputStream("C:/Users/rakib/Desktop/Thesis-15.01.11/Test/dictionary/bivokti.txt");
             FileInputStream fis_bivokti = new FileInputStream("E://ThesisResource_pos/another_tagger/dictionary/bivokti.txt");
            InputStreamReader isr_bivokti = new InputStreamReader(fis_bivokti, "UTF-8");
            BufferedReader b_bivokti = new BufferedReader(isr_bivokti);
            int strtKey = b_bivokti.read();

            while ((str_bivokti = b_bivokti.readLine()) != null) {
                //System.out.println("Got it " + str_bivokti.toString());

                bivokti.add(str_bivokti);

            }
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public void vector_protoy() {
        String str_protoy;

        try {
            //FileInputStream fis_protoy = new FileInputStream("C:/Users/rakib/Desktop/Thesis-15.01.11/Test/dictionary/protoy.txt");
             FileInputStream fis_protoy = new FileInputStream("E://ThesisResource_pos/another_tagger/dictionary/protoy.txt");
            InputStreamReader isr_protoy = new InputStreamReader(fis_protoy, "UTF-8");
            BufferedReader b_protoy = new BufferedReader(isr_protoy);
            int strtKey = b_protoy.read();

            while ((str_protoy = b_protoy.readLine()) != null) {
                //System.out.println("Got it " + str_protoy.toString());

                protoy.add(str_protoy);

            }
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public void vector_uposorgo() {

        String str_uposorgo;

        try {
           // FileInputStream fis_uposorgo = new FileInputStream("C:/Users/rakib/Desktop/Thesis-15.01.11/Test/dictionary/uposorgo.txt");
             FileInputStream fis_uposorgo = new FileInputStream("E://ThesisResource_pos/another_tagger/dictionary/uposorgo.txt");
            InputStreamReader isr_uposorgo = new InputStreamReader(fis_uposorgo, "UTF-8");
            BufferedReader b_uposorgo = new BufferedReader(isr_uposorgo);
            int strtKey = b_uposorgo.read();

            while ((str_uposorgo = b_uposorgo.readLine()) != null) {
                //System.out.println("Got it " + str_bivokti.toString());

                bivokti.add(str_uposorgo);

            }
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public boolean init() {
        Dictionary_hash();
        vector_protoy();
        vector_bivokti();
        vector_uposorgo();
        vector_kal();
        return true;
    }

    public boolean checkDictionary(String str) {
        if (dictionary_tree.containsKey(str)) {
            return true;
        }
        return false;
    }

    public String stemUposorgo(String str) {
        String temp = str;
        for (int i = 0; i < uposorgo.size(); i++) {

            String ustr = uposorgo.get(i).toString();
            //System.out.println(ustr);
            if (str.startsWith(ustr)) {
                temp = str.substring(0 + ustr.length());
                if (checkDictionary(temp)) {
                    return temp;
                }
                //break;
            }
        }
        return str;
    }

    public String stemKal(String str) {
        String temp = str;
        for (int i = 0; i < kal.size(); i++) {
            String ustr = kal.get(i).toString();
            //result_token = dictionary_tree.get(str).toString();
            if (str.substring(0).endsWith(ustr)) {
                temp = str.substring(0, str.lastIndexOf(ustr));
                if (checkDictionary(temp)) {
                    result_pos = dictionary_tree.get(temp).toString();
                    stemmed = ustr;
                    return temp;
                }
                //break;
            }
        }
        return str;
    }

    public String stemBivokti(String str) {
        String temp = str;
        for (int i = 0; i < bivokti.size(); i++) {
            String ustr = bivokti.get(i).toString();
            if (str.substring(0).endsWith(ustr)) {
                temp = str.substring(0, str.lastIndexOf(ustr));
                if (checkDictionary(temp)) {
                    result_pos = dictionary_tree.get(temp).toString();
                    stemmed = ustr;
                    return temp;
                }
                //break;
            }
        }
        return str;
    }

    public String stemProtoy(String str) {
        String temp = str;
        for (int i = 0; i < protoy.size(); i++) {
            String ustr = protoy.get(i).toString();
            if (str.substring(0).endsWith(ustr)) {
                temp = str.substring(0, str.lastIndexOf(ustr));
                if (checkDictionary(temp)) {
                    result_pos = dictionary_tree.get(temp).toString();
                    stemmed = ustr;
                    return temp;
                }
                //break;
            }
        }
        return str;
    }

    public String getSuffKal(String str) {
        String temp = str;
        System.out.println(kal.size() + "--------------");
        for (int i = 0; i < kal.size(); i++) {
            String ustr = kal.get(i).toString();
            //result_token = dictionary_tree.get(str).toString();
            if (str.substring(0).endsWith(ustr)) {
                //System.out.println("++++"+ustr);
                return ustr;
            }
        }
        return null;
    }

    public String getSuffBivokti(String str) {
        String temp = str;
        for (int i = 0; i < bivokti.size(); i++) {
            String ustr = bivokti.get(i).toString();
            if (str.substring(0).endsWith(ustr)) {
                return ustr;
            }
        }
        return null;
    }

    public String getSuffProtoy(String str) {
        String temp = str;
        for (int i = 0; i < protoy.size(); i++) {
            String ustr = protoy.get(i).toString();
            if (str.substring(0).endsWith(ustr)) {
                    return temp;
            }
        }
        return null;
    }
}
