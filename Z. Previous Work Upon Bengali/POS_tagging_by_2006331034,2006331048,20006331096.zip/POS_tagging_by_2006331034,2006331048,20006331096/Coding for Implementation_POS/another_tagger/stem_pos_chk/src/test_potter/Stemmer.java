package test_potter;

public class Stemmer {

    CheckSuffix cs;
    
    String stemmed = "";
    String result_token = "";
    String result_pos = "";
    String result = "";

    public Stemmer(CheckSuffix cs1) {
            cs = cs1;
//        if (!cs.init()) {
//            System.out.println("Stem Failed :");
//            //System.exit(0);
//        }

    }

    public String stem(String str) {
        /*if(checkDictionary(str))
        {
        System.out.println("Matched without Stem:" + str);
        return str;
        }*/

        String str1 = cs.stemBivokti(str);
        if (str1.length() < 2) {
            //System.out.println("+++++++"+str1);
            str1 = str;
        } else if (cs.checkDictionary(str1) && str1 != str) {

            System.out.println("Matched after Stem Bivokti:" + str1);
           result += str + " " + str1 + "+" + cs.stemmed + " " + cs.result_pos + " ";
           //result += str +"/"+ cs.result_pos+" ";
            // System.out.println("-----"+result);
            String tmp = cs.stemmed;
            cs.stemmed = "";
            //return str1;
            return  tmp + " " + cs.result_pos;
        }
        //str = str1;

        String str2 = cs.stemProtoy(str1);
        if (str2.length() < 2) {
            str2 = str1;
        } else if (cs.checkDictionary(str2) && str2 != str1) {
            System.out.println("Matched after Stem Protoy:" + str2);
            result += str + " " + str2 + "+" + cs.stemmed + " " + cs.result_pos + " ";
            //result += str +"/"+ cs.result_pos+" ";
            // System.out.println("-----"+result);
            String tmp = cs.stemmed;
            cs.stemmed = "";
            //return str1;
            return  tmp + " " + cs.result_pos;
        }

        String str3 = cs.stemKal(str2);
        if (str3.length() < 2) {
            str3 = str2;
        } else if (cs.checkDictionary(str3) && str2 != str3) {
            System.out.println("Matched after Stem Kal:" + str3);
            result += str + " " + str3 + "+" + cs.stemmed + " " + cs.result_pos + " ";
           // result += str +"/"+ cs.result_pos+" ";
            //System.out.println("-----"+result);
            String tmp = cs.stemmed;
            cs.stemmed = "";
            //return str1;
            return  tmp + " " + cs.result_pos;
        }
        
        String str4 = cs.stemUposorgo(str3);
        if (str4.length() < 2) {
            str4 = str3;
        } else if (cs.checkDictionary(str4) && str3 != str4) {
            System.out.println("Matched after Stem Uposorgo:" + str4);
            result += str + " " + str4 + "+" + cs.stemmed + " " + cs.result_pos + " ";
            //result += str +"/"+ cs.result_pos+" ";
            //System.out.println("-----"+result);
            String tmp = cs.stemmed;
            cs.stemmed = "";
            //return str1;
            return  tmp + " " + cs.result_pos;
        }
        return str3;
    }
}
