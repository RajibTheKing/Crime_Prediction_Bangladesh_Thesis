package test_potter;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.HashMap;
import java.util.StringTokenizer;

public class GuessPoS {

    public GuessPoS() {
    }
    HashMap<String, String[]> hSuffix = new HashMap<String, String[]>();
    CheckSuffix chk = new CheckSuffix();
    EvaluatePoS ep = new EvaluatePoS();

    public boolean init() {
        hashFreq();
        return chk.init();
    }

    public String guessPoS(String str) {
        // Object info;
        String info[];
        String suffix = getSuffix(str);
        //System.out.println(suffix);

        suffix = ep.replace(suffix);
        System.out.println("----------------------" + suffix);
        String pos = "";
        if (hSuffix.containsKey(suffix)) {
            //pos = hSuffix;
            info = hSuffix.get(suffix);
            pos = info[0];
            System.out.println(pos);
        }

        return pos;
    }

    public String getSuffix(String str) {
        String suffix = chk.getSuffKal(str);

        if (suffix != null) {

            return suffix;
        }
        suffix = chk.getSuffBivokti(str);
        if (suffix != null) {
            return suffix;
        }
        suffix = chk.getSuffProtoy(str);
        if (suffix != null) {
            return suffix;
        }

        return null;
    }

    public void hashFreq() {
        String str;
        String suffix = null;

        String h_info[] = new String[2];

        try {
            //FileInputStream fis = new FileInputStream("C:/Users/rakib/Desktop/Thesis-15.01.11/Test/k_p_b/freq_count.txt");
            FileInputStream fis = new FileInputStream("E://ThesisResource_pos/another_tagger/k_p/freq_count.txt");
            InputStreamReader isr = new InputStreamReader(fis, "UTF-8");
            BufferedReader buf = new BufferedReader(isr);

           // FileOutputStream fos = new FileOutputStream("C:/Users/rakib/Desktop/Thesis-15.01.11/Test/k_p_b/freq_guess.txt");
            FileOutputStream fos = new FileOutputStream("E://ThesisResource_pos/another_tagger/k_p/freq_guess.txt");
            OutputStreamWriter osw = new OutputStreamWriter(fos, "UTF-8");
            BufferedWriter bwr = new BufferedWriter(osw);

            while ((str = buf.readLine()) != null) {    // Used Hashmap,Tokennized hash content-> Inserted

                StringTokenizer token = new StringTokenizer(str);
                if (token.hasMoreTokens()) {
                    suffix = token.nextToken();
                }
                if (token.hasMoreTokens()) {
                    h_info[0] = token.nextToken();
                }
                if (token.hasMoreTokens()) {
                    h_info[1] = token.nextToken();
                }
                hSuffix.put(suffix, h_info);   // Add content to the treeset
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
