package test_potter;

public class Stemmer {

    CheckSuffix cs;
    
    String stemmed = "";
    String result_token = "";
    String result_pos = "";
    String result = "";
    String[] split;
    String suffix_name="";
    String change_unchange="";
    String stemword_pos="";
    String suggest_pos="";
    String stemWord="";
    String prefix="";
    String temp_prefix="";
   // int flag_uposogo=0;

    public Stemmer(CheckSuffix cs1) {
            cs = cs1;
//        if (!cs.init()) {
//            System.out.println("Stem Failed :");
//            //System.exit(0);
//        }

    }

    public String stem(String str) {
        /*if(checkDictionary(str))
        {
        System.out.println("Matched without Stem:" + str);
        return str;
        }*/
        
         String str1 = cs.stemSuffix(str);
        //System.out.println("output from stem"+str1);
        if (str1.length() < 2) {
            //System.out.println("+++++++"+str1);
            str1 = str;
        } else if (cs.checkDictionary(str1) && str1 != str) {
            String mod_val=cs.modifier_val;
             split = mod_val.split("-");
            suffix_name=split[0];
            change_unchange=split[1];
            stemword_pos=split[2];
            suggest_pos=split[3];
            if(change_unchange.equalsIgnoreCase("unchanged"))
            {

            System.out.println("Unchanged so tag from corpus:"+str1+"+"+cs.stemmed_suffix+cs.result_pos);
           result += str + " " + str1 + "+" + cs.stemmed_suffix + "/" + cs.result_pos + " ";
           //result += str +"/"+ cs.result_pos+" ";
            // System.out.println("-----"+result);
            String tmp = cs.stemmed_suffix;
            cs.stemmed_suffix = "";
            //return str1;
            return  tmp + " " + cs.result_pos;
            }
            else
            {
               if(cs.result_pos.equals(stemword_pos))
               {
                    result += str + " " + str1 + "+" + cs.stemmed_suffix + " " +suggest_pos + " ";
                     System.out.println("found rule file and tag:" +str1+"+"+cs.stemmed_suffix+suggest_pos);
               }
               else
               {
                   result += str + " " + str1 + "+" + cs.stemmed_suffix + " " +"S/"+suggest_pos + " ";
                   System.out.println("suggesr tag frm rule file:" +str1+"+"+cs.stemmed_suffix+"S/"+suggest_pos);
               }
                return  cs.stemmed_suffix+ " " +suggest_pos;
            }
        }
        
        
        
           str1 = cs.stemUposorgo(str);
        // System.out.println("output from uposorgo"+str1);
         // String[]   splitUP=new String[6];
       // System.out.println("uposogostem"+cs.stemmed+" "+str2);
        if (str1.length() < 2) {
            str1 = str;
        } else if (cs.checkDictionary(str1) && str1 != str) {
            System.out.println("Matched after Stem Uposorgo:"+cs.stemmed_uposorgo+"+"+ str1+cs.result_pos);
            result += str + " " + cs.stemmed_uposorgo + "+" + str1 +"/"+ cs.result_pos + " ";
            //result += str +"/"+ cs.result_pos+" ";
            //System.out.println("-----"+result);
            String tmp = cs.stemmed_uposorgo;
            cs.stemmed_uposorgo = "";
            //return str1;
            return  tmp + " " + cs.result_pos;
        }
       
        else
        {
            
//            //String tmp=cs.stemmed;
//            if(str.startsWith(cs.stemmed))
//            {
//                String mod_value=cs.modifier_valUP;
//                System.out.println("============="+mod_value);
////                splitUP = mod_value.split("-");
////                
////               String suffix_nameUP=splitUP[0];
////               
////               String change_unchangeUP=splitUP[1];
////               String  stemword_posUP=splitUP[2];
////              String     suggest_posUP=splitUP[1];
//                
          //prefix = str.substring(0 + cs.stemmed.length());
//          prefix=str.substring(0, str.lastIndexOf(cs.stemmed));
            prefix=cs.stemmed_uposorgo;
//          System.out.println("main word str"+str);
//          System.out.println("stemmed"+cs.stemmed_uposorgo.length());
//          System.out.println("uposorgo"+prefix);
//          result += str + " " + cs.stemmed + "+" + temp + " " + mod_value + " ";
         // System.out.println("not found in dic but can stem Uposorgo:" +cs.stemmed+"+"+prefix);
         // return  cs.stemmed + " " +"fhfh";
//            }
         // flag_uposogo=1;
            
              
        }
        
         String str2 = cs.stemSuffix(str1);
        //System.out.println("output from stem"+str1);
        if (str2.length() < 2) {
            //System.out.println("+++++++"+str1);
            str2 = str1;
        } else if (cs.checkDictionary(str2) && str2 != str1) {
            String mod_val=cs.modifier_val;
             split = mod_val.split("-");
            suffix_name=split[0];
            change_unchange=split[1];
            stemword_pos=split[2];
            suggest_pos=split[3];
            if(change_unchange.equalsIgnoreCase("unchanged"))
            {

            System.out.println("Unchanged so tag from corpus:"+str2+"+"+cs.stemmed_suffix+cs.result_pos);
           result += str + " " + str2 + "+" + cs.stemmed_suffix + "/" + cs.result_pos + " ";
           //result += str +"/"+ cs.result_pos+" ";
            // System.out.println("-----"+result);
            String tmp = cs.stemmed_suffix;
            cs.stemmed_suffix = "";
            //return str1;
            return  tmp + " " + cs.result_pos;
            }
            else
            {
               if(cs.result_pos.equals(stemword_pos))
               {
                    result += str + " " + str2 + "+" + cs.stemmed_suffix + " " +suggest_pos + " ";
                     System.out.println("found rule file and tag:" +str2+"+"+cs.stemmed_suffix+suggest_pos);
               }
               else
               {
                   result += str + " " + str2 + "+" + cs.stemmed_suffix + " " +"S/"+suggest_pos + " ";
                   System.out.println("suggesr tag frm rule file:" +str2+"+"+cs.stemmed_suffix+"S/"+suggest_pos);
               }
                return  cs.stemmed_suffix+ " " +suggest_pos;
            }
        }
        else
        {
            //str1 = cs.stemSuffix(str1);
//            if(str.startsWith(cs.stemmed))
//            {
             String mod_val=cs.modifier_val;
            // System.out.println(cs.modifier_val);
             split = mod_val.split("-");
            suffix_name=split[0];
//            change_unchange=split[1];
            stemword_pos=split[2];
            suggest_pos=split[3];
            //String temp = str1.substring(0, str1.lastIndexOf(cs.stemmed)-1);
            if(str.startsWith(prefix)&&(prefix.length()!=0)&&(prefix.length()>=2))
            {
                System.out.println("start with prefix");
            
            }
            else
            //System.out.println("prefix"+prefix);
            // System.out.println("stemWord"+cs.stem_word);
            {
//                System.out.println(str);
//                System.out.println(cs.stem_word);
//                System.out.println(cs.stemmed_suffix);
//                System.out.println(suggest_pos);
             if((str.startsWith(cs.stem_word))&&(cs.stemmed_suffix.length()>=2))
                     {
            result += str + " " + cs.stem_word + "+" + cs.stemmed_suffix + " " +"S/"+suggest_pos + " ";
           System.out.println("can stem but not found in corpus :" +cs.stem_word+"+"+cs.stemmed_suffix+"S/"+suggest_pos);
           String stemmed_suffix=cs.stemmed;
           String sug_pos=suggest_pos;
           cs.stemmed="";
           suggest_pos="";
           return  stemmed_suffix+ " " +"s/"+sug_pos;
                     }
             else
             {
                 return str+" "+"/unknown";
             }
            }
            
//            }
//            else
//            {
//                result += str +"/unknown" + " ";
//           System.out.println("can not stem and not found in corpus :" +str+"/unknown"); 
//            }
            //cs.stem_word="";
           stemWord=cs.stem_word;
          // return  cs.stemmed+ " " +suggest_pos;
           
          
        }
        
        
        
        
           str2 = cs.stemUposorgo(stemWord);
         // String[]   splitUP=new String[6];
       // System.out.println("uposogostem"+cs.stemmed+" "+str2);
        if (str2.length() < 2) {
            str2 = str1;
        } else if (cs.checkDictionary(str2) && str2 != str1) {
            System.out.println("Matched after Stem Uposorgo:"+cs.stemmed_uposorgo+"+"+ str2+cs.result_pos);
            result += str + " " + cs.stemmed_uposorgo + "+" + str2 +"/"+ cs.result_pos + " ";
            //result += str +"/"+ cs.result_pos+" ";
            //System.out.println("-----"+result);
            temp_prefix = cs.stemmed_uposorgo;
            cs.stemmed_uposorgo = "";
            //return str1;
           return  temp_prefix + " " + cs.result_pos;
        }
       
        
        
       
        

       
        //str = str1;

//        String str2 = cs.stemProtoy(str1);
//        if (str2.length() < 2) {
//            str2 = str1;
//        } else if (cs.checkDictionary(str2) && str2 != str1) {
//            System.out.println("Matched after Stem Protoy:" + str2);
//            result += str + " " + str2 + "+" + cs.stemmed + " " + cs.result_pos + " ";
//            //result += str +"/"+ cs.result_pos+" ";
//            // System.out.println("-----"+result);
//            String tmp = cs.stemmed;
//            cs.stemmed = "";
//            //return str1;
//            return  tmp + " " + cs.result_pos;
//        }
//
//        String str3 = cs.stemKal(str2);
//        if (str3.length() < 2) {
//            str3 = str2;
//        } else if (cs.checkDictionary(str3) && str2 != str3) {
//            System.out.println("Matched after Stem Kal:" + str3);
//            result += str + " " + str3 + "+" + cs.stemmed + " " + cs.result_pos + " ";
//           // result += str +"/"+ cs.result_pos+" ";
//            //System.out.println("-----"+result);
//            String tmp = cs.stemmed;
//            cs.stemmed = "";
//            //return str1;
//            return  tmp + " " + cs.result_pos;
//        }
        
          
        
      
        
       
       return str1;
 }
}
