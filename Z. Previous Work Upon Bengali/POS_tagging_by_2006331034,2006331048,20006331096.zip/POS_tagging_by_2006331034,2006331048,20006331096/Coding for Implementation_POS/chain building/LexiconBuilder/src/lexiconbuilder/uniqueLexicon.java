/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package lexiconbuilder;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.StringTokenizer;

/**
 *
 * @author Palash
 */
public class uniqueLexicon {
    FileInputStream fis,ufis;
    DataInputStream dis,udis;
    BufferedReader br,ubr;
    FileOutputStream fos;
    OutputStreamWriter osw;
    BufferedWriter bw;
    StringTokenizer strtok,tokenise;
    HashMap hash = new HashMap();
    String line,token,pos,postemp;
    int i,flag,p;
    public void uniqueLexicon(){
        
    }
    public void lexiconGen(){
        try{
            //ufis = new FileInputStream("H://Thesis/News Tagger/Word Corpus/Tagging/Lexicon/unique.lexicon");
            ufis = new FileInputStream("E://chain building/Lexicon_input/103.lexicon");
            udis = new DataInputStream(ufis);
            ubr = new BufferedReader(new InputStreamReader(udis,"UTF-8"));
            while((line = ubr.readLine())!=null){
                tokenise = new StringTokenizer(line);
                flag = 0;
                while(tokenise.hasMoreTokens()){
                    if(flag==0){
                       token = tokenise.nextElement().toString();
                       flag = 1;
                    }
                   else{
                        pos = tokenise.nextElement().toString();
                   }
                }
                System.out.println(token+" "+pos);
                hash.put(token, pos);
            }
            ubr.close();
            //fos = new FileOutputStream("H://Thesis/News Tagger/Word Corpus/Tagging/Lexicon/unique.lexicon");
            fos = new FileOutputStream("E://chain building/Lexicon/uniqu.lexicon");
            osw = new OutputStreamWriter(fos,"UTF-8");
            bw = new BufferedWriter(osw);
            //fis = new FileInputStream("H://Thesis/News Tagger/Word Corpus/Tagging/Lexicon/103.lexicon");
            fis = new FileInputStream("E://chain building/Lexicon_input/102.lexicon");
            dis = new DataInputStream(fis);
            br = new BufferedReader(new InputStreamReader(dis,"UTF-8"));
            
            while((line = br.readLine())!=null){
                 tokenise = new StringTokenizer(line);
                 flag = 0;
                 while(tokenise.hasMoreTokens()){
                     if(flag==0){
                        token = tokenise.nextElement().toString();
                        flag = 1;
                     }
                    else{
                         pos = tokenise.nextElement().toString();
                    }
                 }
                 if(hash.containsKey(token)){
                     postemp = hash.get(token).toString();
                     if(!pos.equalsIgnoreCase(postemp)){
                         p = Integer.parseInt(postemp) + Integer.parseInt(pos) ;
                        pos=Integer.toString(p);
                         hash.remove(token);
                         hash.put(token,pos);
                     }
                 }
                 else{
                     hash.put(token, pos);
                 }
            }
            Iterator it = hash.keySet().iterator();
            while(it.hasNext()){
                token = it.next().toString();
                pos = hash.get(token).toString();
                //System.out.println(token+" "+pos);
                bw.append("\n"+token+" "+pos);
            }
            bw.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
