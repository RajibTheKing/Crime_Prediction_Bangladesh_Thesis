/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package lexiconbuilder;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.HashMap;
import java.util.StringTokenizer;

/**
 *
 * @author Palash
 */
public class lexiconGenerator {
    FileInputStream fis;
    DataInputStream dis;
    BufferedReader br;
    FileOutputStream fos;
    OutputStreamWriter osw;
    BufferedWriter bw;
    StringTokenizer strtok,tokenise;
    //HashMap hash = new HashMap();
    //HashMap hashcounter = new HashMap();
    public void lexiconGenerator(){

    }
    String line,token,pos,temp;
    int i,len,flag;
    public void builder(){
        try{
            //fis = new FileInputStream("H://Thesis/News Tagger/Word Corpus/Tagging/tagged_half/103.txt");
            fis = new FileInputStream("E://chain building/tagged_half/103.txt");
            dis = new DataInputStream(fis);
            br = new BufferedReader(new InputStreamReader(dis,"UTF-8"));
            //fos = new FileOutputStream("H://Thesis/News Tagger/Word Corpus/Tagging/Lexicon/103.lexicon");
            fos = new FileOutputStream("E://chain building/Lexicon/103.lexicon");
            osw = new OutputStreamWriter(fos,"UTF-8");
            bw = new BufferedWriter(osw);
            //int count = 1;
            while((line = br.readLine())!=null){
                strtok = new StringTokenizer(line," ");
                while(strtok.hasMoreTokens()){
                    temp = strtok.nextElement().toString();
                    tokenise = new StringTokenizer(temp,"/");
                    flag = 0;
                    while(tokenise.hasMoreTokens()){
                        if(flag==0){
                            token = tokenise.nextElement().toString();
                            System.out.println(""+token);
                            //bw.append(token);
                            flag = 1;
                        }
                        else{
                            pos = tokenise.nextElement().toString();
                            bw.append(""+pos+"+");
                            //hash.put(token, pos);
                        }
                    }
                }
                 bw.append("\n");
            }
            bw.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
